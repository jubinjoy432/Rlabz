/**
 * Project Detail Page — JavaScript
 * Reads ?id=xxx, renders all sections, handles lightbox
 */

(function () {
    'use strict';

    // Initialize when data is ready
    let initialized = false;
    window.addEventListener('projectsLoaded', () => {
        if (!initialized) {
            initialized = true;
            init();
        }
    });
    if (window.RLABZ_PROJECTS && window.RLABZ_PROJECTS.length > 0 && !initialized) {
        initialized = true;
        init();
    }

    function init() {
        const params = new URLSearchParams(window.location.search);
        const projectId = params.get('id');

        if (!projectId) {
            showNotFound();
            return;
        }

        const project = getProjectById(projectId);
        if (!project) {
            showNotFound();
            return;
        }

        renderPage(project);
        setupLightbox(project);
    }

    function showNotFound() {
        const wrapper = document.getElementById('pdContentArea');
        if (wrapper) {
            wrapper.innerHTML = `
                <div class="pd-not-found">
                    <i class="fa-solid fa-folder-open"></i>
                    <h2>Project Not Found</h2>
                    <p>The project you're looking for doesn't exist or may have been moved.</p>
                    <a href="projects.html"><i class="fa-solid fa-arrow-left"></i> Back to Projects</a>
                </div>
            `;
        }
    }

    function renderPage(project) {
        // Set page title
        document.title = `${project.title} — RLabz Project Repository`;

        // Hero
        renderHero(project);

        // Navigation
        renderNavigation(project);

        // Main content
        renderOverview(project);
        renderTimeline(project);
        renderScreenshots(project);
        renderFeatures(project);

        // Sidebar
        renderTechnologies(project);
        renderInfoTable(project);
        renderTeam(project);
        renderFaculty(project);

        // Footer nav
        renderFooterNav(project);
    }

    function renderHero(project) {
        const banner = document.getElementById('pdHeroBanner');
        const title = document.getElementById('pdHeroTitle');
        const tagline = document.getElementById('pdHeroTagline');
        const meta = document.getElementById('pdHeroMeta');

        if (banner) {
            const img = banner.querySelector('img');
            if (img) {
                img.src = project.thumbnail || '../assets/images/logo1.png';
                img.alt = project.title;
                img.onerror = function () { this.src = '../assets/images/logo1.png'; };
            }
        }

        if (title) title.textContent = project.title;
        if (tagline) tagline.textContent = project.shortDescription || project.fullDescription || '';

        if (meta) {
            const statusClass = project.status === 'In Development' ? 'status-in-development' : 'status-completed';

            let badges = `<span class="pd-meta-badge pd-meta-year"><i class="fa-regular fa-calendar"></i> ${project.year}</span>`;
            if (project.department) {
                badges += `<span class="pd-meta-badge pd-meta-dept"><i class="fa-solid fa-building-columns"></i> ${project.department}</span>`;
            }
            badges += `<span class="pd-meta-badge pd-meta-status ${statusClass}">${project.status}</span>`;
            if (project.category) {
                badges += `<span class="pd-meta-badge pd-meta-dept"><i class="fa-solid fa-layer-group"></i> ${project.category}</span>`;
            }
            meta.innerHTML = badges;
        }
        
        const actionsContainer = document.getElementById('pdHeroActions');
        if (actionsContainer) {
            if (project.sslDomain) {
                actionsContainer.innerHTML = `<a href="${project.sslDomain}" target="_blank" class="pd-visit-website-btn">Visit Website &rarr;</a>`;
            } else {
                actionsContainer.innerHTML = '';
            }
        }
    }

    function renderNavigation(project) {
        const { prev, next } = getAdjacentProjects(project.id);

        const prevBtn = document.getElementById('pdPrevBtn');
        const nextBtn = document.getElementById('pdNextBtn');

        if (prevBtn) {
            if (prev) {
                prevBtn.href = `project-details.html?id=${prev.id}`;
                prevBtn.classList.remove('disabled');
            } else {
                prevBtn.classList.add('disabled');
            }
        }

        if (nextBtn) {
            if (next) {
                nextBtn.href = `project-details.html?id=${next.id}`;
                nextBtn.classList.remove('disabled');
            } else {
                nextBtn.classList.add('disabled');
            }
        }
    }

    function renderOverview(project) {
        const container = document.getElementById('pdOverview');
        if (!container) return;

        let html = '';

        if (project.fullDescription) {
            html += `<div class="pd-overview-block"><h4>Description</h4><p>${project.fullDescription}</p></div>`;
        }
        if (project.objectives) {
            html += `<div class="pd-overview-block"><h4>Objectives</h4><p>${project.objectives}</p></div>`;
        }
        if (project.problemStatement) {
            html += `<div class="pd-overview-block"><h4>Problem Statement</h4><p>${project.problemStatement}</p></div>`;
        }
        if (project.expectedOutcome) {
            html += `<div class="pd-overview-block"><h4>Expected Outcome</h4><p>${project.expectedOutcome}</p></div>`;
        }

        container.innerHTML = html || '<p style="color: rgba(255,255,255,0.3);">No description available yet.</p>';
    }

    function renderTimeline(project) {
        const card = document.getElementById('pdTimelineCard');
        const container = document.getElementById('pdTimelineContent');
        if (!card || !container) return;

        if (!project.milestones || project.milestones.length === 0) {
            card.style.display = 'none';
            return;
        }

        container.innerHTML = project.milestones.map(m => {
            // Format date to a readable string (e.g. Aug 15, 2026)
            const dateObj = new Date(m.date);
            const dateStr = dateObj.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
            return `
                <div class="pd-timeline-item status-${m.status}">
                    <div class="pd-timeline-date">${dateStr}</div>
                    <div class="pd-timeline-title">${m.title}</div>
                </div>
            `;
        }).join('');
    }

    function renderScreenshots(project) {
        const card = document.getElementById('pdScreenshotsCard');
        const grid = document.getElementById('pdScreenshotsGrid');
        if (!card || !grid) return;

        let screenshots = project.screenshots && project.screenshots.length > 0
            ? project.screenshots.filter(src => src && typeof src === 'string' && src.trim() !== '')
            : [];

        if (screenshots.length === 0) {
            card.style.display = 'none';
            return;
        }

        card.style.display = '';

        const getImgPath = (path) => (path && (path.startsWith('uploads/') || path.startsWith('images/'))) ? '../' + path : path;

        grid.innerHTML = screenshots.map((src, i) =>
            `<div class="pd-screenshot-item" data-index="${i}">
                <img src="${getImgPath(src)}" alt="${project.title} screenshot ${i + 1}" loading="lazy" onerror="this.onerror=null; this.closest('.pd-screenshot-item').style.display='none'; if(Array.from(this.closest('#pdScreenshotsGrid').children).every(c => c.style.display === 'none')) document.getElementById('pdScreenshotsCard').style.display='none';">
            </div>`
        ).join('');
    }

    function renderFeatures(project) {
        const card = document.getElementById('pdFeaturesCard');
        const grid = document.getElementById('pdFeaturesGrid');
        if (!card || !grid) return;

        if (!project.keyFeatures || project.keyFeatures.length === 0) {
            card.style.display = 'none';
            return;
        }

        grid.innerHTML = project.keyFeatures.map(f =>
            `<div class="pd-feature-item">
                <span class="pd-feature-check"><i class="fa-solid fa-check"></i></span>
                <span class="pd-feature-text">${f}</span>
            </div>`
        ).join('');
    }

    function renderTechnologies(project) {
        const grid = document.getElementById('pdTechGrid');
        if (!grid) return;
        const card = document.getElementById('pdTechCard') || grid.closest('.pd-card');

        const validTech = Array.isArray(project.tech)
            ? project.tech.map(t => typeof t === 'string' ? t.trim() : '').filter(t => t.length > 0)
            : [];

        if (validTech.length === 0) {
            if (card) card.style.display = 'none';
            grid.innerHTML = '';
            return;
        }

        if (card) card.style.display = '';
        grid.innerHTML = validTech.map(t =>
            `<span class="pd-tech-badge">${t}</span>`
        ).join('');
    }

    function renderInfoTable(project) {
        const table = document.getElementById('pdInfoTable');
        if (!table) return;

        const rows = [];

        if (project.year) rows.push({ label: 'Project Year', value: project.year });
        if (project.batch) rows.push({ label: 'Batch', value: project.batch });
        if (project.department) rows.push({ label: 'Department', value: project.department });
        if (project.faculty && project.faculty.length > 0) {
            const facultyNames = project.faculty
                .filter(f => f && f.name && f.name.trim() !== '')
                .map(f => f.name).join(', ');
            if (facultyNames) {
                rows.push({ label: 'Guide', value: facultyNames });
            }
        }
        if (project.projectType) rows.push({ label: 'Project Type', value: project.projectType });
        if (project.category) rows.push({ label: 'Category', value: project.category });
        if (project.duration) rows.push({ label: 'Duration', value: project.duration });
        if (project.status) rows.push({ label: 'Status', value: project.status });
        if (project.client) rows.push({ label: 'Client', value: project.client });
        if (project.githubLink) rows.push({ label: 'Repository', value: `<a href="${project.githubLink}" target="_blank" rel="noopener"><i class="fa-brands fa-github"></i> GitHub</a>` });
        if (project.demoLink && project.demoLink !== '#') rows.push({ label: 'Demo Link', value: `<a href="${project.demoLink}" target="_blank" rel="noopener"><i class="fa-solid fa-external-link-alt"></i> Visit</a>` });
        
        if (project.ssl && project.ssl.domain_url) {
            let sslText = `<a href="${project.ssl.domain_url}" target="_blank" rel="noopener" style="color:#10b981;"><i class="fa-solid fa-lock"></i> Secured</a>`;
            if (project.ssl.provider) sslText += ` by ${project.ssl.provider}`;
            rows.push({ label: 'SSL Certificate', value: sslText });
        }

        table.innerHTML = rows.map(r =>
            `<div class="pd-info-row">
                <span class="pd-info-label">${r.label}</span>
                <span class="pd-info-value">${r.value}</span>
            </div>`
        ).join('');
    }

    function renderTeam(project) {
        const card = document.getElementById('pdTeamCard');
        const grid = document.getElementById('pdTeamGrid');
        if (!card || !grid) return;

        if (!project.team || project.team.length === 0) {
            grid.innerHTML = '<div class="pd-team-empty">Team information will be updated soon.</div>';
            return;
        }

        grid.innerHTML = project.team.map(member => {
            const photoHtml = member.photo ? `<img src="${member.photo}" alt="${member.name}" class="pd-team-avatar" loading="lazy" onerror="this.style.display='none'">` : '';
            let liUrl = member.linkedin;
            if (liUrl && !/^https?:\/\//i.test(liUrl)) {
                liUrl = 'https://' + liUrl;
            }
            const linkedinHtml = liUrl ? `<a href="${liUrl}" target="_blank" rel="noopener" class="pd-team-linkedin" style="color: #0077b5; font-size: 1.1rem; margin-left: 0.3rem;"><i class="fa-brands fa-linkedin"></i></a>` : '';
            return `
                <div class="pd-team-card">
                    ${photoHtml}
                    <div class="pd-team-name" style="display:flex; justify-content:center; align-items:center;">
                        ${member.name}
                        ${linkedinHtml}
                    </div>
                    ${member.role ? `<div class="pd-team-role">${member.role}</div>` : ''}
                    ${member.regNo ? `<div class="pd-team-reg">${member.regNo}</div>` : ''}
                </div>
            `;
        }).join('');
    }

    function renderFaculty(project) {
        const card = document.getElementById('pdFacultyCard');
        const container = document.getElementById('pdFacultyContent');
        if (!card || !container) return;

        const validFaculty = Array.isArray(project.faculty)
            ? project.faculty.filter(f => f && f.name && f.name.trim() !== '')
            : [];

        if (validFaculty.length === 0) {
            card.style.display = 'none';
            container.innerHTML = '';
            return;
        }

        card.style.display = '';
        container.style.display = 'grid';
        container.style.gridTemplateColumns = 'repeat(auto-fit, minmax(200px, 1fr))';
        container.style.gap = '1.5rem';

        container.innerHTML = validFaculty.map(f => {
            const photoHtml = f.photo ? `<img src="${f.photo}" alt="${f.name}" class="pd-faculty-avatar" loading="lazy" onerror="this.style.display='none'">` : '';
            let liUrl = f.linkedin;
            if (liUrl && !/^https?:\/\//i.test(liUrl)) {
                liUrl = 'https://' + liUrl;
            }
            const linkedinHtml = liUrl ? `<a href="${liUrl}" target="_blank" rel="noopener" class="pd-team-linkedin" style="color: #0077b5; font-size: 1.1rem; margin-left: 0.5rem;"><i class="fa-brands fa-linkedin"></i></a>` : '';
            return `
                <div class="pd-faculty-card">
                    ${photoHtml}
                    <div class="pd-faculty-info">
                        <h4 style="display:flex; align-items:center; margin:0;">${f.name} ${linkedinHtml}</h4>
                        ${f.designation ? `<div class="pd-faculty-designation">${f.designation}</div>` : ''}
                        <span class="pd-faculty-label"><i class="fa-solid fa-user-tie"></i> Faculty In-Charge</span>
                    </div>
                </div>
            `;
        }).join('');
    }

    function renderFooterNav(project) {
        const { prev, next } = getAdjacentProjects(project.id);

        const prevLink = document.getElementById('pdFooterPrev');
        const nextLink = document.getElementById('pdFooterNext');

        if (prevLink) {
            if (prev) {
                prevLink.href = `project-details.html?id=${prev.id}`;
                prevLink.innerHTML = `<i class="fa-solid fa-arrow-left"></i> ${prev.title}`;
                prevLink.classList.remove('disabled');
            } else {
                prevLink.classList.add('disabled');
                prevLink.innerHTML = `<i class="fa-solid fa-arrow-left"></i> Previous`;
            }
        }

        if (nextLink) {
            if (next) {
                nextLink.href = `project-details.html?id=${next.id}`;
                nextLink.innerHTML = `${next.title} <i class="fa-solid fa-arrow-right"></i>`;
                nextLink.classList.remove('disabled');
            } else {
                nextLink.classList.add('disabled');
                nextLink.innerHTML = `Next <i class="fa-solid fa-arrow-right"></i>`;
            }
        }
    }

    // ---- Lightbox ----
    function setupLightbox(project) {
        const lightbox = document.getElementById('pdLightbox');
        const lightboxImg = document.getElementById('pdLightboxImg');
        const lightboxClose = document.getElementById('pdLightboxClose');
        const lightboxPrev = document.getElementById('pdLightboxPrev');
        const lightboxNext = document.getElementById('pdLightboxNext');
        const lightboxCounter = document.getElementById('pdLightboxCounter');

        if (!lightbox || !lightboxImg) return;

        const screenshots = project.screenshots && project.screenshots.length > 0
            ? project.screenshots
            : (project.thumbnail ? [project.thumbnail] : []);

        if (screenshots.length === 0) return;

        let currentIndex = 0;

        function openLightbox(index) {
            currentIndex = index;
            lightboxImg.src = screenshots[currentIndex];
            lightbox.classList.add('active');
            document.body.style.overflow = 'hidden';
            updateCounter();
        }

        function closeLightbox() {
            lightbox.classList.remove('active');
            document.body.style.overflow = '';
        }

        function navigateLightbox(direction) {
            currentIndex = (currentIndex + direction + screenshots.length) % screenshots.length;
            lightboxImg.src = screenshots[currentIndex];
            updateCounter();
        }

        function updateCounter() {
            if (lightboxCounter) {
                lightboxCounter.textContent = `${currentIndex + 1} / ${screenshots.length}`;
            }
        }

        // Click screenshot to open
        document.addEventListener('click', (e) => {
            const item = e.target.closest('.pd-screenshot-item');
            if (item) {
                const idx = parseInt(item.getAttribute('data-index'), 10);
                openLightbox(idx);
            }
        });

        if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
        if (lightboxPrev) lightboxPrev.addEventListener('click', () => navigateLightbox(-1));
        if (lightboxNext) lightboxNext.addEventListener('click', () => navigateLightbox(1));

        // Click backdrop to close
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) closeLightbox();
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (!lightbox.classList.contains('active')) return;
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') navigateLightbox(-1);
            if (e.key === 'ArrowRight') navigateLightbox(1);
        });
    }

})();
