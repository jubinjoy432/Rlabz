<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../login.php");
    exit;
}
require_once 'db.php';

function normalize_image_url($url) {
    if (empty($url)) return '';
    $url = trim($url);
    if (preg_match('/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/i', $url, $matches)) {
        return "https://lh3.googleusercontent.com/d/" . $matches[1];
    }
    return $url;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        header("Location: ../dashboard.php?error=" . urlencode("Project ID is missing."));
        exit;
    }

    // Fetch existing project to get current data and image paths
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        header("Location: ../dashboard.php?error=" . urlencode("Project not found."));
        exit;
    }

    $slug = trim($_POST['slug'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $year = trim($_POST['year'] ?? '');
    $short_description = trim($_POST['short_description'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $objectives = trim($_POST['objectives'] ?? '');
    $problem_statement = trim($_POST['problem_statement'] ?? '');
    $expected_outcome = trim($_POST['expected_outcome'] ?? '');
    $tech_stack = trim($_POST['tech_stack'] ?? '');
    $department = trim($_POST['department'] ?? 'MCA');
    if ($department === 'Other' && !empty(trim($_POST['department_custom'] ?? ''))) {
        $department = trim($_POST['department_custom']);
    }

    $batch = trim($_POST['batch'] ?? '');

    $category = trim($_POST['category'] ?? 'Web Application');
    if ($category === 'Other' && !empty(trim($_POST['category_custom'] ?? ''))) {
        $category = trim($_POST['category_custom']);
    }
    $project_type = trim($_POST['project_type'] ?? 'Academic');
    
    // Status preservation and validation
    $valid_statuses = ['In Development', 'Completed'];
    $submitted_status = trim($_POST['status'] ?? '');
    if (in_array($submitted_status, $valid_statuses)) {
        $status = $submitted_status;
    } else {
        // Preserve existing project status if valid, else fallback to 'In Development'
        $status = in_array($project['status'], $valid_statuses) ? $project['status'] : 'In Development';
    }

    $duration = trim($_POST['duration'] ?? '');
    $github_link = trim($_POST['github_link'] ?? '');
    $demo_link = trim($_POST['demo_link'] ?? '');
    $ssl_tracking_enabled = isset($_POST['ssl_tracking_enabled']) ? 1 : 0;
    
    if (empty($title) || empty($year) || empty($description)) {
        header("Location: ../edit_project.php?id=$id&error=" . urlencode("Title, Year, and Description are required."));
        exit;
    }

    if (empty($short_description)) {
        $short_description = $description;
    }

    if (empty($slug)) {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
        $slug = trim($slug, '-');
    }

    $uploadDir = '../../uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    function handleUpload($fileInputName, $existingPath) {
        global $allowed, $uploadDir, $id;
        if (isset($_FILES[$fileInputName]) && $_FILES[$fileInputName]['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES[$fileInputName]['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed) && $_FILES[$fileInputName]['size'] <= 5 * 1024 * 1024) {
                $filename = uniqid($fileInputName . '_') . '.' . $ext;
                if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $uploadDir . $filename)) {
                    return 'uploads/' . $filename;
                }
            }
        }
        
        if (isset($_POST['delete_' . $fileInputName]) && $_POST['delete_' . $fileInputName] == '1') {
            return '';
        }
        
        return $existingPath;
    }

    $image_path = $project['image_path'];
    $thumbnail_path = handleUpload('thumbnail', $project['thumbnail_path']);
    
    // If no new file uploaded but thumbnail_url provided, use normalized URL
    if (!empty($_POST['thumbnail_url']) && (empty($_FILES['thumbnail']['name']) || $_FILES['thumbnail']['error'] !== UPLOAD_ERR_OK)) {
        $thumbnail_path = normalize_image_url($_POST['thumbnail_url']);
    }

    $poster_path = $project['poster_path'];

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("UPDATE projects SET 
            slug = ?, title = ?, year = ?, short_description = ?, description = ?, 
            objectives = ?, problem_statement = ?, expected_outcome = ?, tech_stack = ?, 
            key_features = ?, department = ?, batch = ?, category = ?, project_type = ?, 
            status = ?, duration = ?, 
            github_link = ?, demo_link = ?, image_path = ?, thumbnail_path = ?, poster_path = ?,
            ssl_tracking_enabled = ?
            WHERE id = ?");
        
        $stmt->execute([
            $slug, $title, $year, $short_description, $description,
            $objectives, $problem_statement, $expected_outcome, $tech_stack,
            $key_features, $department, $batch, $category, $project_type,
            $status, $duration,
            $github_link, $demo_link, $image_path, $thumbnail_path, $poster_path,
            $ssl_tracking_enabled,
            $id
        ]);

        // Process team members (Dynamic rows with upload or URL)
        if (isset($_POST['member_names']) && is_array($_POST['member_names'])) {
            $member_names = $_POST['member_names'];
            $member_roles = $_POST['member_roles'] ?? [];
            $member_linkedin = $_POST['member_linkedin'] ?? [];
            $existing_photos = $_POST['existing_photos'] ?? [];
            $member_photo_urls = $_POST['member_photo_urls'] ?? [];
            $member_photos = $_FILES['member_photos'] ?? null;
            
            // Delete old members
            $delStmt = $pdo->prepare("DELETE FROM project_members WHERE project_id = ?");
            $delStmt->execute([$id]);

            $memStmt = $pdo->prepare("INSERT INTO project_members (project_id, name, role, photo_path, linkedin_link) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($member_names as $index => $m_name) {
                $m_name = trim($m_name);
                if (empty($m_name)) continue;

                $m_role = trim($member_roles[$index] ?? '');
                $m_linkedin = trim($member_linkedin[$index] ?? '');
                $m_photo_path = trim($existing_photos[$index] ?? '');

                if (isset($member_photos['name'][$index]) && $member_photos['error'][$index] === UPLOAD_ERR_OK) {
                    $m_ext = strtolower(pathinfo($member_photos['name'][$index], PATHINFO_EXTENSION));
                    if (in_array($m_ext, $allowed)) {
                        $m_filename = uniqid('member_') . '.' . $m_ext;
                        if (move_uploaded_file($member_photos['tmp_name'][$index], $uploadDir . $m_filename)) {
                            $m_photo_path = 'uploads/' . $m_filename;
                        }
                    }
                } elseif (!empty($member_photo_urls[$index])) {
                    $m_photo_path = normalize_image_url($member_photo_urls[$index]);
                }
                
                $memStmt->execute([$id, $m_name, $m_role, $m_photo_path, $m_linkedin]);
            }
        }

        // Process faculty members (Dynamic rows with upload or URL)
        if (isset($_POST['faculty_names']) && is_array($_POST['faculty_names'])) {
            $faculty_names = $_POST['faculty_names'];
            $faculty_designations = $_POST['faculty_designations'] ?? [];
            $faculty_linkedin = $_POST['faculty_linkedin'] ?? [];
            $existing_faculty_photos = $_POST['existing_faculty_photos'] ?? [];
            $faculty_photo_urls = $_POST['faculty_photo_urls'] ?? [];
            $faculty_photos = $_FILES['faculty_photos'] ?? null;
            
            // Delete old faculty
            $delFacStmt = $pdo->prepare("DELETE FROM project_faculty WHERE project_id = ?");
            $delFacStmt->execute([$id]);

            $facStmt = $pdo->prepare("INSERT INTO project_faculty (project_id, name, designation, photo_path, linkedin_link) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($faculty_names as $index => $f_name) {
                $f_name = trim($f_name);
                if (empty($f_name)) continue;

                $f_designation = trim($faculty_designations[$index] ?? '');
                $f_linkedin = trim($faculty_linkedin[$index] ?? '');
                $f_photo_path = trim($existing_faculty_photos[$index] ?? '');

                if (isset($faculty_photos['name'][$index]) && $faculty_photos['error'][$index] === UPLOAD_ERR_OK) {
                    $f_ext = strtolower(pathinfo($faculty_photos['name'][$index], PATHINFO_EXTENSION));
                    if (in_array($f_ext, $allowed)) {
                        $f_filename = uniqid('faculty_') . '.' . $f_ext;
                        if (move_uploaded_file($faculty_photos['tmp_name'][$index], $uploadDir . $f_filename)) {
                            $f_photo_path = 'uploads/' . $f_filename;
                        }
                    }
                } elseif (!empty($faculty_photo_urls[$index])) {
                    $f_photo_path = normalize_image_url($faculty_photo_urls[$index]);
                }
                
                $facStmt->execute([$id, $f_name, $f_designation, $f_photo_path, $f_linkedin]);
            }
        }

        // --- Handle Screenshots Deletion ---
        if (isset($_POST['delete_screenshots']) && is_array($_POST['delete_screenshots'])) {
            $delScreenshotStmt = $pdo->prepare("SELECT image_path FROM project_screenshots WHERE id = ? AND project_id = ?");
            $delStmt = $pdo->prepare("DELETE FROM project_screenshots WHERE id = ? AND project_id = ?");
            foreach ($_POST['delete_screenshots'] as $ss_id) {
                $delScreenshotStmt->execute([$ss_id, $id]);
                if ($ssInfo = $delScreenshotStmt->fetch(PDO::FETCH_ASSOC)) {
                    $physical_path = '../../' . $ssInfo['image_path'];
                    if (file_exists($physical_path)) {
                        unlink($physical_path);
                    }
                    $delStmt->execute([$ss_id, $id]);
                }
            }
        }

        // --- Handle New Screenshots Upload ---
        if (isset($_FILES['new_screenshots'])) {
            $ss_files = $_FILES['new_screenshots'];
            $ssStmt = $pdo->prepare("INSERT INTO project_screenshots (project_id, image_path, sort_order) VALUES (?, ?, 0)");
            
            for ($i = 0; $i < count($ss_files['name']); $i++) {
                if ($ss_files['error'][$i] === UPLOAD_ERR_OK) {
                    $ss_ext = strtolower(pathinfo($ss_files['name'][$i], PATHINFO_EXTENSION));
                    if (in_array($ss_ext, $allowed) && $ss_files['size'][$i] <= 5 * 1024 * 1024) {
                        $ss_filename = uniqid('screenshot_') . '.' . $ss_ext;
                        if (move_uploaded_file($ss_files['tmp_name'][$i], $uploadDir . $ss_filename)) {
                            $ssStmt->execute([$id, 'uploads/' . $ss_filename]);
                        }
                    }
                }
            }
        }

        // --- Handle SSL Details ---
        $ssl_domain = isset($_POST['ssl_domain']) ? trim($_POST['ssl_domain']) : '';
        $pdo->prepare("DELETE FROM project_ssl_certs WHERE project_id = ?")->execute([$id]);
        if (!empty($ssl_domain)) {
            $ssl_provider = isset($_POST['ssl_provider']) ? trim($_POST['ssl_provider']) : '';
            $ssl_issue_date = !empty($_POST['ssl_issue_date']) ? $_POST['ssl_issue_date'] : null;
            $ssl_expiry_date = !empty($_POST['ssl_expiry_date']) ? $_POST['ssl_expiry_date'] : null;
            $ssl_fingerprint = !empty($_POST['ssl_fingerprint']) ? $_POST['ssl_fingerprint'] : null;
            
            $stmtSsl = $pdo->prepare("INSERT INTO project_ssl_certs (project_id, domain_url, provider, issue_date, expiry_date, certificate_fingerprint) VALUES (?, ?, ?, ?, ?, ?)");
            $stmtSsl->execute([$id, $ssl_domain, $ssl_provider, $ssl_issue_date, $ssl_expiry_date, $ssl_fingerprint]);
        }

        if ($pdo->inTransaction()) {
            $pdo->commit();
        }
        header("Location: ../edit_project.php?id=$id&success=" . urlencode("Project updated successfully!"));
        exit;

    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        header("Location: ../edit_project.php?id=$id&error=" . urlencode("Database Error: " . $e->getMessage()));
        exit;
    }
} else {
    header("Location: ../dashboard.php");
    exit;
}
