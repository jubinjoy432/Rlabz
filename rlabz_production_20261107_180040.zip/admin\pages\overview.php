<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../login.php");
    exit;
}
require_once '../api/db.php';

$pageTitle = "Overview";

// Fetch Stats
$totalProjects = 0;
$completedProjects = 0;
$deployedProjects = 0;
$inDevProjects = 0;
$totalMembers = 0;
$activeSslMonitors = 0;
$sslIssues = 0;
$recentProjects = [];

$chartDataStatus = ['Completed' => 0, 'In Development' => 0];
$chartDataYear = [];

if ($pdo) {
    try {
        // Stats queries
        $stmt = $pdo->query("SELECT status, year, title, category FROM projects ORDER BY year DESC, id DESC");
        $allProjects = $stmt->fetchAll();
        $totalProjects = count($allProjects);
        
        foreach ($allProjects as $p) {
            if ($p['status'] === 'Completed') $completedProjects++;
            if ($p['status'] === 'In Development') $inDevProjects++;
            
            if (isset($chartDataStatus[$p['status']])) {
                $chartDataStatus[$p['status']]++;
            }
            
            $y = $p['year'] ? $p['year'] : 'N/A';
            $chartDataYear[$y] = ($chartDataYear[$y] ?? 0) + 1;
        }

        $stmtMembers = $pdo->query("SELECT COUNT(*) FROM project_members");
        $totalMembers = $stmtMembers->fetchColumn();

        // SSL Monitoring Stats
        $stmtSslStats = $pdo->query("
            SELECT 
                COUNT(*) as total_monitored,
                SUM(CASE WHEN status != 'active' OR (expiry_date IS NOT NULL AND DATEDIFF(expiry_date, CURDATE()) < 30) THEN 1 ELSE 0 END) as issues
            FROM project_ssl_certs
        ");
        $sslStats = $stmtSslStats->fetch();
        $activeSslMonitors = $sslStats['total_monitored'] ?: 0;
        $sslIssues = $sslStats['issues'] ?: 0;

        // Recent 5
        $stmtRecent = $pdo->query("SELECT id, title, slug, status, year, image_path, category FROM projects ORDER BY id DESC LIMIT 5");
        $recentProjects = $stmtRecent->fetchAll();

        // Admin Announcements
        $stmtAnnouncements = $pdo->query("SELECT * FROM admin_announcements WHERE is_read = 0 ORDER BY created_at DESC LIMIT 50");
        $announcements = $stmtAnnouncements->fetchAll();
        $unreadCount = 0;
        foreach ($announcements as $a) {
            if (!$a['is_read']) $unreadCount++;
        }

    } catch (PDOException $e) {
        $error = "Failed to load stats: " . $e->getMessage();
    }
}

// Format for JS
$statusLabels = json_encode(array_keys($chartDataStatus));
$statusData = json_encode(array_values($chartDataStatus));

ksort($chartDataYear);
$yearLabels = json_encode(array_keys($chartDataYear));
$yearData = json_encode(array_values($chartDataYear));

require_once '../includes/layout_header.php';
?>

<?php if(isset($error)): ?>
    <div class="alert alert-error"><i class="fa-solid fa-exclamation-triangle"></i> <?php echo $error; ?></div>
<?php endif; ?>

<div class="page-header">
    <div class="page-header-left">
        <h1>Dashboard Overview</h1>
        <p>Welcome back! Here's what's happening with your projects.</p>
    </div>
    <div>
        <a href="add_project.php" class="btn-header primary"><i class="fa-solid fa-plus"></i> New Project</a>
    </div>
</div>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card stat-blue">
        <div class="stat-card-icon"><i class="fa-solid fa-folder-open"></i></div>
        <div class="stat-card-value"><?php echo $totalProjects; ?></div>
        <div class="stat-card-label">Total Projects</div>
    </div>
    <div class="stat-card stat-green">
        <div class="stat-card-icon"><i class="fa-solid fa-check-circle"></i></div>
        <div class="stat-card-value"><?php echo $completedProjects; ?></div>
        <div class="stat-card-label">Completed</div>
    </div>
    <div class="stat-card stat-amber">
        <div class="stat-card-icon"><i class="fa-solid fa-code"></i></div>
        <div class="stat-card-value"><?php echo $inDevProjects; ?></div>
        <div class="stat-card-label">In Development</div>
    </div>
    <div class="stat-card stat-teal">
        <div class="stat-card-icon"><i class="fa-solid fa-users"></i></div>
        <div class="stat-card-value"><?php echo $totalMembers; ?></div>
        <div class="stat-card-label">Team Members</div>
    </div>


</div>

<!-- Charts Row -->
<div class="charts-grid">
    <div class="chart-container">
        <h3><i class="fa-solid fa-chart-pie"></i> Projects by Status</h3>
        <div class="chart-wrapper donut">
            <canvas id="statusChart"></canvas>
        </div>
    </div>
    <div class="chart-container">
        <h3><i class="fa-solid fa-chart-bar"></i> Projects by Year</h3>
        <div class="chart-wrapper">
            <canvas id="yearChart" style="height: 250px;"></canvas>
        </div>
    </div>
</div>

<!-- Admin Announcements -->
<div class="card" style="display: flex; flex-direction: column; max-height: 440px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 0.75rem;">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <h2 style="margin: 0; padding: 0; border: none; font-size: 1.15rem; display: flex; align-items: center; gap: 0.5rem; color: var(--text-primary);">
                <i class="fa-solid fa-bell" style="color: #f59e0b;"></i> SSL Expiry & Announcements
            </h2>
            <span id="unread-count" style="display: inline-flex; align-items: center; padding: 0.25rem 0.7rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 700; background: <?php echo $unreadCount > 0 ? '#fef3c7' : '#f1f5f9'; ?>; color: <?php echo $unreadCount > 0 ? '#b45309' : '#64748b'; ?>; border: 1px solid <?php echo $unreadCount > 0 ? '#fde68a' : '#e2e8f0'; ?>;">
                <?php echo $unreadCount; ?> new
            </span>
        </div>
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <?php if($unreadCount > 0): ?>
            <button type="button" onclick="markAllReadOverview()" id="btn-mark-all-read" style="display: inline-flex; align-items: center; gap: 0.4rem; background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; border-radius: 7px; padding: 0.45rem 0.85rem; font-size: 0.82rem; font-weight: 600; cursor: pointer; transition: all 0.2s ease;">
                <i class="fa-solid fa-check-double"></i> <span>Mark All Read</span>
            </button>
            <?php endif; ?>
            <a href="announcements.php" style="display: inline-flex; align-items: center; gap: 0.4rem; background: #eff6ff; color: #1d4ed8; border: 1px solid #bfdbfe; border-radius: 7px; padding: 0.45rem 0.85rem; font-size: 0.82rem; font-weight: 600; text-decoration: none; cursor: pointer; transition: all 0.2s ease;">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> <span>View All</span>
            </a>
            <a href="ssl_certificates.php" style="display: inline-flex; align-items: center; gap: 0.4rem; background: #f8fafc; color: var(--text-secondary); border: 1px solid var(--border); border-radius: 7px; padding: 0.45rem 0.85rem; font-size: 0.82rem; font-weight: 600; text-decoration: none; cursor: pointer; transition: all 0.2s ease;">
                <i class="fa-solid fa-shield-halved" style="color: var(--accent-blue);"></i> <span>SSL Tracker</span>
            </a>
            <button type="button" onclick="refreshSslNow()" id="btn-refresh-cron" style="display: inline-flex; align-items: center; gap: 0.4rem; background: #0b5394; color: #ffffff; border: 1px solid rgba(255,255,255,0.15); border-radius: 7px; padding: 0.45rem 0.85rem; font-size: 0.82rem; font-weight: 600; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <i class="fa-solid fa-rotate"></i> <span>Check SSL</span>
            </button>
        </div>
    </div>
    <div class="announcements-container" style="flex: 1; overflow-y: auto; padding-right: 5px; display: flex; flex-direction: column; gap: 10px;">
        <?php if(empty($announcements)): ?>
            <div style="text-align:center; padding: 2.5rem 1rem; color: var(--text-muted); font-size: 0.9rem;">
                <i class="fa-solid fa-circle-check" style="font-size: 1.8rem; color: #10b981; margin-bottom: 0.5rem; display: block;"></i>
                All clear! No pending SSL expiry notices or unread announcements.
            </div>
        <?php else: ?>
            <?php foreach($announcements as $a): 
                $type = $a['type'] ?? '';
                $severity = $a['severity'] ?? 'info';
                
                // MAIN PURPOSE HIGHLIGHT: Expiring SSL vs Expired vs Failed
                if (in_array($type, ['ssl_notice', 'ssl_warning', 'ssl_critical']) || stripos($a['title'], 'Expiring') !== false) {
                    // Vibrant Amber / Gold for Expiring Soon
                    $icon = 'fa-hourglass-half';
                    $color = '#b45309';
                    $bg = '#fef3c7';
                    $border = '#f59e0b';
                    $pillBg = '#fef3c7';
                    $pillColor = '#92400e';
                    $pillText = 'Expiring Soon';
                } elseif ($type === 'ssl_expired' || stripos($a['title'], 'Expired') !== false) {
                    // Urgent Red for Expired (<= 0 days)
                    $icon = 'fa-triangle-exclamation';
                    $color = '#b91c1c';
                    $bg = '#fee2e2';
                    $border = '#ef4444';
                    $pillBg = '#fee2e2';
                    $pillColor = '#991b1b';
                    $pillText = 'Expired';
                } elseif ($type === 'ssl_failed' || $severity === 'danger' || stripos($a['title'], 'Check Failed') !== false) {
                    // Crimson Rose for Check Failed
                    $icon = 'fa-circle-xmark';
                    $color = '#be123c';
                    $bg = '#ffe4e6';
                    $border = '#f43f5e';
                    $pillBg = '#ffe4e6';
                    $pillColor = '#9f1239';
                    $pillText = 'Check Failed';
                } elseif ($type === 'ssl_renewed' || $severity === 'success') {
                    // Green for Renewed
                    $icon = 'fa-shield-heart';
                    $color = '#15803d';
                    $bg = '#dcfce7';
                    $border = '#22c55e';
                    $pillBg = '#dcfce7';
                    $pillColor = '#166534';
                    $pillText = 'Renewed';
                } else {
                    // General info
                    $icon = 'fa-info-circle';
                    $color = '#1d4ed8';
                    $bg = '#dbeafe';
                    $border = '#3b82f6';
                    $pillBg = '#dbeafe';
                    $pillColor = '#1e40af';
                    $pillText = 'Notice';
                }
                
                $opacity = $a['is_read'] ? '0.65' : '1';
                $borderLeft = $a['is_read'] ? '4px solid #cbd5e1' : "4px solid $border";
            ?>
            <div class="announcement-item" id="announcement-<?= $a['id'] ?>" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 7px; padding: 8px 12px; display: flex; align-items: center; gap: 10px; border-left: <?= $borderLeft ?>; opacity: <?= $opacity ?>; transition: all 0.2s ease; box-shadow: 0 1px 2px rgba(0,0,0,0.02);">
                <div style="color: <?= $color ?>; background: <?= $bg ?>; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 0.85rem;">
                    <i class="fa-solid <?= $icon ?>"></i>
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap: nowrap; gap: 0.5rem;">
                        <span style="font-weight: 600; color: #0f172a; font-size: 0.86rem; display: inline-flex; align-items: center; gap: 0.45rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            <?= htmlspecialchars($a['title']) ?>
                            <span style="font-size: 0.68rem; font-weight: 700; padding: 0.08rem 0.45rem; border-radius: 9999px; background: <?= $pillBg ?>; color: <?= $pillColor ?>; flex-shrink: 0;"><?= $pillText ?></span>
                        </span>
                        <span style="font-size:0.72rem; color:#94a3b8; font-weight:500; flex-shrink: 0;"><i class="fa-regular fa-clock" style="font-size: 0.68rem;"></i> <?= date('M j, g:i A', strtotime($a['created_at'])) ?></span>
                    </div>
                    <div style="font-size: 0.8rem; color: #475569; line-height: 1.35; white-space: pre-line; word-break: break-word; margin-top: 1px;"><?= htmlspecialchars($a['message']) ?></div>
                </div>
                <?php if(!$a['is_read']): ?>
                    <button class="btn-action" style="align-self: center; background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; border-radius: 5px; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; flex-shrink: 0; font-size: 0.75rem;" title="Mark as Read" onclick="markRead(<?= $a['id'] ?>)">
                        <i class="fa-solid fa-check"></i>
                    </button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
async function markRead(id) {
    try {
        const res = await fetch(`../api/mark_announcement_read.php?id=${id}`);
        const data = await res.json();
        if(data.success) {
            const item = document.getElementById(`announcement-${id}`);
            if (item) item.remove();
            
            // Check if container is empty
            const container = document.querySelector('.announcements-container');
            if (container && container.querySelectorAll('.announcement-item').length === 0) {
                container.innerHTML = `
                    <div style="text-align:center; padding: 2.5rem 1rem; color: var(--text-muted); font-size: 0.9rem;">
                        <i class="fa-solid fa-circle-check" style="font-size: 1.8rem; color: #10b981; margin-bottom: 0.5rem; display: block;"></i>
                        All clear! No pending SSL expiry notices or unread announcements.
                    </div>
                `;
                const markAllBtn = document.getElementById('btn-mark-all-read');
                if (markAllBtn) markAllBtn.remove();
            }
            
            const badge = document.getElementById('unread-count');
            let count = parseInt(badge.textContent);
            if(count > 0) {
                count--;
                badge.textContent = count + ' new';
                if(count === 0) {
                    badge.style.background = '#f1f5f9';
                    badge.style.color = '#64748b';
                    badge.style.borderColor = '#e2e8f0';
                }
            }
        }
    } catch(e) { console.error('Failed to mark read', e); }
}

async function markAllReadOverview() {
    try {
        const res = await fetch(`../api/mark_announcement_read.php?action=mark_all_read`);
        const data = await res.json();
        if(data.success) {
            window.location.reload();
        }
    } catch(e) { console.error('Failed to mark all read', e); }
}


async function refreshSslNow() {
    const btn = document.getElementById('btn-refresh-cron');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Checking...';
    btn.disabled = true;
    try {
        await fetch(`../api/cron_ssl_reminder.php`);
        window.location.reload();
    } catch(e) {
        alert('Failed to run SSL check.');
        btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Check SSL';
        btn.disabled = false;
    }
}
</script>

<!-- Recent Projects -->
<div class="card">
    <h2><i class="fa-solid fa-clock-rotate-left"></i> Recently Added</h2>
    <div style="overflow-x:auto;">
        <table class="recent-table">
            <thead>
                <tr>
                    <th>Project</th>
                    <th>Category</th>
                    <th>Year</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($recentProjects)): ?>
                    <tr><td colspan="5" style="text-align:center; color:var(--text-muted);">No projects found.</td></tr>
                <?php else: ?>
                    <?php foreach($recentProjects as $p): ?>
                    <tr>
                        <td>
                            <div style="display:flex; align-items:center; gap:0.75rem;">
                                <?php
                                    $ovImg = $p['image_path'] ?? '';
                                    $ovSrc = empty($ovImg) 
                                        ? '../../assets/images/logo1.png' 
                                        : (preg_match('#^https?://#i', $ovImg) ? $ovImg : '../../' . ltrim($ovImg, '/'));
                                ?>
                                <img src="<?php echo htmlspecialchars($ovSrc); ?>" class="project-thumb" alt="thumb" onerror="this.onerror=null;this.src='../../assets/images/logo1.png';">
                                <div>
                                    <div class="project-title-cell"><?php echo htmlspecialchars($p['title']); ?></div>
                                    <div class="project-title-meta">/<?php echo htmlspecialchars($p['slug']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td style="color:var(--text-secondary);"><?php echo htmlspecialchars($p['category']); ?></td>
                        <td>
                            <span class="badge badge-default"><?php echo htmlspecialchars($p['year']); ?></span>
                        </td>
                        <td>
                            <?php
                                $statusClass = ($p['status'] === 'Completed') ? 'badge-completed' : 'badge-dev';
                            ?>
                            <span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($p['status']); ?></span>
                        </td>
                        <td>
                            <div class="project-actions">
                                <a href="../edit_project.php?id=<?php echo $p['id']; ?>" class="btn-action btn-edit" title="Edit"><i class="fa-solid fa-pen"></i></a>
                                <a href="../../public/project-details.html?id=<?php echo htmlspecialchars($p['slug']); ?>" class="btn-action btn-preview" title="View" target="_blank"><i class="fa-solid fa-eye"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Chart.js Default Config for Dark Theme
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.font.family = "'Outfit', sans-serif";
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(15, 23, 42, 0.9)';
    Chart.defaults.plugins.tooltip.padding = 12;
    Chart.defaults.plugins.tooltip.cornerRadius = 8;
    Chart.defaults.plugins.tooltip.borderColor = 'rgba(255,255,255,0.1)';
    Chart.defaults.plugins.tooltip.borderWidth = 1;

    // Status Chart (Doughnut)
    const ctxStatus = document.getElementById('statusChart').getContext('2d');
    new Chart(ctxStatus, {
        type: 'doughnut',
        data: {
            labels: <?php echo $statusLabels; ?>,
            datasets: [{
                data: <?php echo $statusData; ?>,
                backgroundColor: ['#10b981', '#f59e0b'],
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '75%',
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, padding: 15 } }
            }
        }
    });

    // Year Chart (Bar)
    const ctxYear = document.getElementById('yearChart').getContext('2d');
    new Chart(ctxYear, {
        type: 'bar',
        data: {
            labels: <?php echo $yearLabels; ?>,
            datasets: [{
                label: 'Projects',
                data: <?php echo $yearData; ?>,
                backgroundColor: 'rgba(56, 189, 248, 0.2)',
                borderColor: '#38bdf8',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { stepSize: 1 } },
                x: { grid: { display: false } }
            }
        }
    });
</script>

<?php require_once '../includes/layout_footer.php'; ?>
